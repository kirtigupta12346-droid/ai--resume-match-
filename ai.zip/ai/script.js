function generateResumePreview() {
  const fullName = document.getElementById("fullName")?.value || "Your Name";
  const jobTitle = document.getElementById("jobTitle")?.value || "Your role";
  const email = document.getElementById("email")?.value || "Email";
  const phone = document.getElementById("phone")?.value || "Phone";
  const summary = document.getElementById("summary")?.value || "Your summary preview will appear here.";
  const skills = document.getElementById("skills")?.value || "Your skills will appear here.";
  const education = document.getElementById("education")?.value || "Your education will appear here.";
  const projects = document.getElementById("projects")?.value || "Your projects will appear here.";
  const experience = document.getElementById("experience")?.value || "Your experience will appear here.";

  document.getElementById("previewName").textContent = fullName;
  document.getElementById("previewRole").textContent = jobTitle;
  document.getElementById("previewContact").textContent = `${email} | ${phone}`;
  document.getElementById("previewSummary").textContent = summary;
  document.getElementById("previewSkills").textContent = skills;
  document.getElementById("previewEducation").textContent = education;
  document.getElementById("previewProjects").textContent = projects;
  document.getElementById("previewExperience").textContent = experience;
}

function updateResumeScore() {
  const type = document.getElementById("resumeType")?.value;
  const scoreCircle = document.getElementById("scoreCircle");
  const circleScoreText = document.getElementById("circleScoreText");
  const atsLabel = document.getElementById("atsLabel");
  const strengthLabel = document.getElementById("strengthLabel");
  const improveLabel = document.getElementById("improveLabel");

  const scoreMap = {
    frontend: {
      score: 84,
      ats: "Good ATS formatting with strong frontend relevance.",
      strength: "Resume has useful UI, HTML, CSS, and JavaScript alignment.",
      improve: "Add React, API integration, and measurable project results."
    },
    backend: {
      score: 79,
      ats: "Readable structure with decent backend format compatibility.",
      strength: "Python and Django alignment is visible in the profile.",
      improve: "Add authentication, APIs, database depth, and deployment."
    },
    fullstack: {
      score: 88,
      ats: "Very strong ATS compatibility and balanced tech stack.",
      strength: "Good mix of frontend, backend, and project-based experience.",
      improve: "Add one strong deployed full-stack product with outcomes."
    },
    designer: {
      score: 75,
      ats: "Readable design resume, but needs stronger portfolio language.",
      strength: "UI/design direction is visible in the profile.",
      improve: "Add Figma, case studies, UX process, and portfolio links."
    }
  };

  const data = scoreMap[type];
  if (!data) return;

  scoreCircle.style.setProperty("--score", data.score);
  circleScoreText.textContent = `${data.score}%`;
  atsLabel.textContent = data.ats;
  strengthLabel.textContent = data.strength;
  improveLabel.textContent = data.improve;
}

function updateJobMatches() {
  const role = document.getElementById("jobRoleSelect")?.value;
  const jobList = document.getElementById("jobList");

  const jobMap = {
    frontend: [
      ["FE", "Frontend Developer", "TechNova", "Noida, India", "Full-time"],
      ["UI", "UI Developer", "PixelCraft", "Remote", "Full-time"],
      ["WD", "Web Designer", "Creative Labs", "Delhi, India", "Hybrid"]
    ],
    backend: [
      ["BE", "Backend Developer", "CodeCore", "Bangalore, India", "Full-time"],
      ["DJ", "Django Developer", "AppStack", "Remote", "Contract"],
      ["PY", "Python Developer", "DataNest", "Lucknow, India", "Hybrid"]
    ],
    fullstack: [
      ["FS", "Full Stack Developer", "BuildFlow", "Gurgaon, India", "Full-time"],
      ["SE", "Software Engineer", "DevBridge", "Remote", "Full-time"],
      ["WA", "Web App Developer", "LaunchGrid", "Hyderabad, India", "Hybrid"]
    ],
    designer: [
      ["UX", "UI/UX Designer", "DesignMint", "Remote", "Full-time"],
      ["PD", "Product Designer", "FlowLabs", "Bangalore, India", "Hybrid"],
      ["WD", "Web Designer", "ArtPixel", "Noida, India", "Contract"]
    ]
  };

  const jobs = jobMap[role];
  if (!jobs) return;

  jobList.innerHTML = "";

  jobs.forEach(job => {
    const card = document.createElement("div");
    card.className = "job-card";
    card.innerHTML = `
      <div class="job-logo">${job[0]}</div>
      <div>
        <h4>${job[1]}</h4>
        <p>${job[2]}</p>
        <div class="job-meta">
          <span>${job[3]}</span>
          <span>${job[4]}</span>
        </div>
      </div>
      <button class="primary-btn small-btn">Apply</button>
    `;
    jobList.appendChild(card);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("resumeType")) {
    updateResumeScore();
  }

  if (document.getElementById("jobRoleSelect")) {
    updateJobMatches();
  }
});